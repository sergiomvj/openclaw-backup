# Guia de Instalação Proxmox VE — Hostel

> **Hardware:** i7 3ª gen | 16GB RAM | SSD 512GB | RJ45 nativa
> **Objetivo:** MikroTik CHR + FreePBX + DNS Server para gerenciamento de rede do hostel

---

## FASE 1 — Preparação

### 1.1 — O que baixar

- **Proxmox VE 8.x ISO:** https://www.proxmox.com/en/downloads
  - Baixar a ISO mais recente (Proxmox VE 8.x - ISO Installer)
- **Rufus** (ou BalenaEtcher) pra criar o pendrive bootável: https://rufus.ie
- **MikroTik CHR image:** https://mikrotik.com/download
  - Baixar a imagem **Raw disk image** (chr-7.x.img.zip)
- **FreePBX ISO:** https://www.freepbx.org/downloads/
  - Baixar a ISO do FreePBX (base CentOS/Debian)

### 1.2 — Pendrive bootável

1. Insira um pendrive de **pelo menos 4GB**
2. Abra o Rufus
3. Selecione a ISO do Proxmox
4. Device → seu pendrive
5. Partition scheme → **GPT**
6. File system → **FAT32**
7. Clique em **Start**
8. Aguarde terminar

### 1.3 — Verificar BIOS do i7 3ª gen

Antes de instalar, entre na BIOS (tecla DEL ou F2 no boot):

1. **Virtualização (VT-x):** Deve estar **Enabled**
   - Geralmente em: Advanced → CPU Configuration → Intel Virtualization Technology
2. **VT-d (IOMMU):** **Enabled** se disponível
3. **Secure Boot:** **Disabled** (Proxmox não assina com keys da Microsoft)
4. **Boot Order:** Coloque o pendrive em primeiro
5. Salve e saia (F10)

---

## FASE 2 — Instalação do Proxmox

### 2.1 — Boot pelo pendrive

1. Ligue o PC com o pendrive inserido
2. Se não bootar automaticamente, aperte **F12** (ou F8/F11 dependendo da placa) para boot menu
3. Selecione o pendrive
4. Vai aparecer o instalador do Proxmox

### 2.2 — Instalação

**Tela 1 — Welcome:**
- Selecione **Install Proxmox VE (Graphical)**
- Aceite o EULA

**Tela 2 — Target Harddisk:**
- Selecione o **SSD 512GB**
- Filesystem → **ext4** (mais simples, suficiente)
- Clique em **Options** → hdsize → deixe **auto** (usa todo o disco)
- Next

**Tela 3 — Country/Timezone:**
- Country: **Brazil**
- Timezone: **America/Sao_Paulo** (ou seu fuso)
- Keyboard Layout: **Portuguese (Brazil)** ou **English (US)**
- Next

**Tela 4 — Administration:**
- Password: **escolha uma senha forte e ANOTE**
- Email: seu email (para notificações do Proxmox)
- Next

**Tela 5 — Network:**
- Management Interface: **selecione a RJ45 nativa**
- Hostname: **pve-hostel** (ou o nome que preferir)
- IP Address: **192.168.0.100** (vamos ajustar depois)
- Netmask: **255.255.255.0** (/24)
- Gateway: **192.168.0.1** (seu roteador atual pra acessar internet durante setup)
- DNS: **1.1.1.1**
- Next

**Tela 6 — Confirm:**
- Revise tudo e clique em **Install**
- Aguarde (5-10 minutos)
- Ao terminar, remova o pendrive e clique **Reboot**

### 2.3 — Primeiro acesso

Após reboot:

1. A tela vai mostrar algo como:
   ```
   Proxmox VE running on pve-hostel
   Web interface: https://192.168.0.100:8006
   ```
2. No seu computador, abra o navegador
3. Acesse: **https://192.168.0.100:8006**
4. ⚠️ Vai dar aviso de certificado — clique em **Avançado** → **Continuar**
5. Login:
   - Username: **root**
   - Password: a senha que criou
   - Realm: **Linux PAM**
6. Clique em **Login**

### 2.4 — Primeira configuração

Após login, o Proxmox pode mostrar um wizard:

1. **No Subscription** → clique em **Next** (sem pagar, funciona normalmente)
2. Marque **No** pra relatório de telemetry (opcional)

---

## FASE 3 — Atualização do Proxmox

No painel web do Proxmox:

1. Clique no node **pve-hostel** (lado esquerdo)
2. Clique em **Shell** (ou **Console**)
3. Digite os comandos:

```bash
# Remover repositório enterprise (necessário sem subscription)
sed -i 's/^deb/#deb/' /etc/apt/sources.list.d/pve-enterprise.list

# Adicionar repositório gratuito
echo "deb http://download.proxmox.com/debian/pve bookworm pve-no-subscription" > /etc/apt/sources.list.d/pve-no-subscription.list

# Atualizar
apt update && apt upgrade -y

# Reiniciar se necessário
reboot
```

---

## FASE 4 — Configurar USB-RJ45

### 4.1 — Plugar o adaptador USB

1. Com o Proxmox ligado, plug o adaptador USB-RJ45
2. No shell do Proxmox:

```bash
# Verificar se foi detectado
ip link show
```

Você deve ver 3 interfaces:
- **lo** (loopback)
- **eno1** ou **enp0s25** (RJ45 nativa — já configurada como management)
- **enx...** (o adaptador USB — nome varia)

```bash
# Anote o nome da interface USB
# Exemplo: enx001122334455
```

### 4.2 — Testar a interface USB

```bash
# Subir a interface temporariamente
ip link set enx001122334455 up
ip addr show enx001122334455
```

Se aparecer "state UP", está funcionando.

---

## FASE 5 — Criar VM MikroTik CHR

### 5.1 — Upload da imagem CHR

No shell do Proxmox:

```bash
# Criar diretório temporário
mkdir -p /tmp/chr

# Copiar a imagem CHR que você baixou (via SCP ou pendrive)
# Se usar SCP do seu computador:
# scp chr-7.x.img.zip root@192.168.0.100:/tmp/chr/

# Descompactar
cd /tmp/chr
unzip chr-7.x.img.zip
# ou: gunzip chr-7.x.img.gz

# O arquivo resultante será chr-7.x.img
```

### 5.2 — Criar VM e importar disco

No **shell do Proxmox:**

```bash
# Criar a VM
qm create 100 \
  --name "MikroTik-CHR" \
  --memory 512 \
  --cores 2 \
  --cpu host \
  --net0 virtio,bridge=vmbr0 \
  --net1 virtio,bridge=vmbr1 \
  --ostype other \
  --onboot 1 \
  --startonboot 1

# Importar a imagem CHR para o disco da VM
qm importdisk 100 /tmp/chr/chr-7.x.img local-lvm

# Anexar o disco importado
qm set 100 --scsi0 local-lvm:vm-100-disk-0

# Definir disco de boot
qm set 100 --boot order=scsi0
```

### 5.3 — Criar bridge para WAN (vmbr1)

No painel web:

1. Clique em **pve-hostel** → **System** → **Network**
2. Clique em **Create** → **Linux Bridge**
3. Configure:
   - Name: **vmbr1**
   - IPv4/CID: deixe em branco (sem IP)
   - Bridge ports: **enx001122334455** (nome da interface USB)
   - Comment: "WAN Bridge"
4. Clique em **Apply Configuration**

### 5.4 — Interfaces da VM MikroTik

A VM 100 foi criada com:
- **net0** → vmbr0 (LAN — RJ45 nativa)
- **net1** → vmbr1 (WAN — adaptador USB)

No painel web:
1. Clique na VM **100 (MikroTik-CHR)**
2. Verifique em **Hardware** se as duas redes estão lá
3. Clique em **Start**

### 5.5 — Acessar o MikroTik

```bash
# No shell do Proxmox, abrir console da VM
qm terminal 100
```

Ou pelo painel web: clique na VM → **Console**

Primeiro acesso MikroTik:
```
# Login padrão
Username: admin
Password: (vazio, só Enter)

# Ele vai pedir pra definir senha nova — defina!
```

### 5.6 — Configuração básica do MikroTik

Pelo console da VM:

```routeros
# Identificar as interfaces
/interface print
# Anote qual é a WAN e qual é a LAN

# Dar nome às interfaces
/interface ethernet set ether1 name="WAN"
/interface ethernet set ether2 name="LAN"

# Configurar WAN (DHCP client - recebe IP do modem)
/ip dhcp-client add interface=WAN disabled=no

# Configurar LAN
/ip address add address=10.0.0.1/24 interface=LAN

# DHCP Server para a rede do hostel
/ip pool add name=dhcp_pool ranges=10.0.0.50-10.0.0.200
/ip dhcp-server add name=dhcp1 interface=LAN address-pool=dhcp_pool disabled=no
/ip dhcp-server network add address=10.0.0.0/24 gateway=10.0.0.1 dns-server=10.0.0.1

# DNS
/ip dns set allow-remote-requests=yes
/ip dns static add name=hostel.local address=10.0.0.1

# NAT (masquerade para internet)
/ip firewall nat add chain=srcnat out-interface=WAN action=masquerade

# Firewall básico
/ip firewall filter add chain=input action=accept protocol=icmp
/ip firewall filter add chain=input action=accept connection-state=established,related
/ip firewall filter add chain=input action=accept in-interface=LAN
/ip firewall filter add chain=input action=drop
```

Agora acesse o MikroTik via Winbox ou web:
- **http://10.0.0.1**
- Conecte um computador na RJ45 nativa (via switch) com DHCP

---

## FASE 6 — Criar VM FreePBX

### 6.1 — Upload da ISO

```bash
# Copiar a ISO do FreePBX para o Proxmox
# Via SCP:
scp FreePBX-x.x.iso root@192.168.0.100:/var/lib/vz/template/iso/
```

Ou pelo painel web:
1. Clique em **local (pve-hostel)** → **ISO Images**
2. Clique em **Upload**
3. Selecione a ISO do FreePBX
4. Aguarde o upload

### 6.2 — Criar a VM

No painel web:

1. Clique em **Create VM** (canto superior direito)
2. **General:**
   - VM ID: **200**
   - Name: **FreePBX**
3. **OS:**
   - ISO Image: selecione a ISO do FreePBX
   - Type: **Linux**
4. **System:**
   - Machine: **q35**
   - BIOS: **OVMF (UEFI)** (se disponível, senão SeaBIOS)
   - SCSI Controller: **VirtIO SCSI**
5. **Disk:**
   - Bus/Device: **SCSI / 0**
   - Storage: **local-lvm**
   - Disk size: **20 GB**
6. **CPU:**
   - Sockets: **1**
   - Cores: **2**
   - Type: **host**
7. **Memory:**
   - Memory: **2048 MB**
   - Uncheck "Ballooning"
8. **Network:**
   - Bridge: **vmbr0** (LAN)
   - Model: **VirtIO**
9. **Confirm** → **Create**

### 6.3 — Instalar o FreePBX

1. Selecione a VM **200 (FreePBX)**
2. Clique em **Start**
3. Clique em **Console**
4. Siga o instalador — geralmente é Next → Next com defaults
5. Quando pedir rede, configure:
   - IP: **10.0.0.10**
   - Mask: **255.255.255.0**
   - Gateway: **10.0.0.1**
   - DNS: **10.0.0.1**
6. Defina senha root
7. Aguarde a instalação (15-30 minutos)
8. Ao reiniciar, acesse via navegador: **http://10.0.0.10**
9. Siga o wizard inicial do FreePBX (criar admin user, etc.)

---

## FASE 7 — Configurar Grandstream HT814

### 7.1 — Conectar o HT814

1. Ligue o HT814 na energia
2. Conecte a porta **LAN** do HT814 no switch TP-Link
3. O HT814 vai receber IP via DHCP (ex: 10.0.0.50)

### 7.2 — Acessar configuração

1. No navegador: **http://10.0.0.50** (ou o IP que recebeu)
2. Login padrão:
   - Username: **admin**
   - Password: **admin**

### 7.3 — Atualizar firmware

1. Vá em **Maintenance** → **Upgrade**
2. Verifique se há atualização disponível
3. Atualize antes de configurar

### 7.4 — Registrar no FreePBX

No **FreePBX** (http://10.0.0.10):

1. Vá em **Applications** → **Extensions**
2. Clique em **Add Extension** → **Add SIP [chan_pjsip] Extension**
3. Para cada ramal:
   - Extension Number: **100** (recepção), **101** (portaria), etc.
   - Display Name: **Recepção**, **Portaria**, etc.
   - Secret: gere uma senha forte
   - Submit → Apply Config

No **HT814:**

1. Vá em **FXS Ports** → **Port 1**
2. Configure:
   - SIP Server: **10.0.0.10**
   - SIP UserID: **100**
   - Authenticate ID: **100**
   - Authenticate Password: (senha do ramal no FreePBX)
3. Repita para as portas 2, 3, 4
4. **Save and Apply**

### 7.5 — Testar

1. Ligue um telefone analógico na porta FXS 1
2. Tire o fone do gancho — deve ouvir tom de discar
3. Ligue do ramal 100 pro 101 — deve tocar

---

## FASE 8 — DNS Server (AdGuard Home)

### 8.1 — Criar container LXC

No **shell do Proxmox:**

```bash
# Download template Debian 12
pveam download local debian-12-standard_12.2-1_amd64.tar.zst

# Criar container
pct create 300 local:vztmpl/debian-12-standard_12.2-1_amd64.tar.zst \
  --hostname "AdGuard-DNS" \
  --memory 512 \
  --cores 1 \
  --net0 name=eth0,bridge=vmbr0,ip=dhcp \
  --storage local-lvm \
  --rootfs local-lvm:4 \
  --onboot 1 \
  --unprivileged 1
```

No painel web:
1. Selecione o container **300**
2. Clique em **Start**
3. Clique em **Console**

### 8.2 — Instalar AdGuard Home

No console do container:

```bash
# Atualizar
apt update && apt upgrade -y

# Instalar dependências
apt install curl tar -y

# Baixar e instalar AdGuard Home
curl -s -S -L https://raw.githubusercontent.com/AdguardTeam/AdGuardHome/master/scripts/install.sh | sh -s -- -v
```

Após instalação:
1. Acesse: **http://10.0.0.x:3000** (IP do container)
2. Siga o wizard:
   - Web interface port: **80**
   - DNS server port: **53**
3. Crie usuário admin

### 8.3 — Apontar MikroTik para o AdGuard

No MikroTik (via Winbox ou terminal):

```routeros
# Configurar DNS server como o AdGuard
/ip dns set servers=10.0.0.x allow-remote-requests=yes

# No DHCP server, informar o DNS
/ip dhcp-server network set 0 dns-server=10.0.0.x
```

---

## FASE 9 — Diagrama Final da Rede

```
┌──────────────────────────────────────────────────┐
│                  INTERNET                        │
│              (1 ou 2 links)                      │
└──────────────────┬───────────────────────────────┘
                   │
          ┌────────▼────────┐
          │  USB-RJ45 (WAN) │
          └────────┬────────┘
                   │
    ┌──────────────▼──────────────┐
    │      Proxmox VE (host)      │
    │  i7 3ª gen / 16GB / SSD    │
    │                             │
    │  ┌───────────────────────┐  │
    │  │   VM 100 — MikroTik   │  │
    │  │   WAN + LAN + NAT     │  │
    │  │   Load Balance        │  │
    │  │   Firewall            │  │
    │  └───────────┬───────────┘  │
    │              │               │
    │  ┌───────────▼───────────┐  │
    │  │   VM 200 — FreePBX    │  │
    │  │   PBX / Ramais SIP    │  │
    │  │   URA / Gravação      │  │
    │  └───────────┬───────────┘  │
    │              │               │
    │  ┌───────────▼───────────┐  │
    │  │  LXC 300 — AdGuard    │  │
    │  │  DNS / Bloqueio ads   │  │
    │  └───────────────────────┘  │
    └──────────────┬──────────────┘
                   │
          ┌────────▼────────┐
          │ RJ45 nativa LAN │
          └────────┬────────┘
                   │
          ┌────────▼────────┐
          │ Switch TP-Link  │
          │   SG108E        │
          └──┬──┬──┬──┬──┬──┘
             │  │  │  │  │
     ┌───────┘  │  │  │  └───────┐
     ▼          ▼  ▼  ▼          ▼
  HT814    Routers  Routers   Outros
  (FXS)    (bridge) (bridge)  dispositivos
     │
  Telefones
  analógicos
```

---

## FASE 10 — Checklist Pós-Instalação

- [ ] Proxmox acessível via https://IP:8006
- [ ] MikroTik CHR rodando, WAN com internet, LAN distribuindo DHCP
- [ ] FreePBX acessível via web, ramais criados
- [ ] HT814 registrado no FreePBX, tom de discar nos telefones analógicos
- [ ] AdGuard Home bloqueando ads e resolvendo DNS
- [ ] Firewall do MikroTik ativo (bloqueando entrada externa)
- [ ] Backup automático configurado no Proxmox (para o HD extra quando tiver)
- [ ] Senhas documentadas em local seguro
- [ ] Winbox instalado no seu computador para gerenciar o MikroTik

---

## Comandos Úteis

```bash
# Ver status das VMs
qm list

# Ver status dos containers
pct list

# Reiniciar uma VM
qm reboot 100

# Console de uma VM
qm terminal 100

# Console de um container
pct enter 300

# Backup manual de todas as VMs
vzdump --all --mode stop --storage local --compress zstd

# Ver uso de recursos
htop
```

---

## Notas Finais

- **Senha root do Proxmox:** NÃO PERCA. É a única forma de acesso.
- **Winbox:** Baixe em https://mikrotik.com/download para gerenciar o MikroTik graficamente
- **FreePBX:** Sempre clique em "Apply Config" após mudanças
- **Backups:** Configure backup automático semanal pelo Proxmox (Datacenter → Backup)
- **Monitoramento:** O painel do Proxmox já mostra CPU/RAM/Disco em tempo real

---

*Guia criado por David ⚡ — 31/05/2026*
*Projeto: Infraestrutura de rede do Hostel*
