# Scenario: FBRSigns

## Perfil
- **Tipo:** Serviço (comunicação visual / signage)
- **Cliente ideal:** PMEs em Orlando — restaurantes e imobiliárias como clusters primários
- **Mercado:** Orlando / Central Florida, B2B2C
- **Estágio:** Early stage — presença digital limitada, sem clientes consolidados
- **Ticket médio:** $500–$5,000 por projeto (estimativa com base no mercado)
- **Ciclo de vendas:** 1–4 semanas (projeto simples) a 2–3 meses (projeto complexo)
- **Tipo de decisão:** B2B — proprietário/gerente decide
- **Data de criação:** 2026-05-31
- **Última atualização:** 2026-05-31

---

## Estratégia de Captação
**Gerado em:** 2026-05-31
**Fase atual:** Descoberta (zero de presença digital ativa)

### Descoberta
- Abordagem primária: Orgânico passivo (SEO + Google Business Profile) — maior intenção de busca
- Abordagem secundária: Outbound local (visita presencial + networking) — mercado hiperlocal de Orlando

### Atenção
- Padrão primário: Prova — portfolio visual + before/after de projetos na região
- Padrão secundário: Identificação — falar das dores do proprietário (falta visibilidade, concorrência)

### Registro
- Modelo primário: Troca de valor — orçamento grátis + consulta visual gratuita
- Modelo secundário: Conteúdo contínuo — Instagram com projetos executados + dicas de comunicação visual

### Ações em execução
| # | Ação | Canal | Status | Início | Resultado |
|---|---|---|---|---|---|
| (a preencher conforme execução) |

---

## Nutrição
**Gerado em:** 2026-05-31

### Plano de nutrição
| # | Ação | Canal | Frequência | Status |
|---|---|---|---|---|
| (a preencher conforme execução) |

### Definição de lead quente para este produto
- Pediu orçamento via site, telefone ou presencialmente
- Respondeu a DM ou email de outreach
- Agendou consulta visual gratuita
- Visitou o showroom/espaço físico
- Pediu indicação de parceiro e entrou em contato

---

## Leads

### Quentes (interação positiva registrada)
| Lead | Empresa | Canal | Interação positiva | Data | Status | Fase atual |
|---|---|---|---|---|---|---|
| (a preencher conforme execução) |

### Frios (captados, sem interação positiva)
| Lead | Empresa | Canal | Ação de captação | Data captura | Última nutrição | Próxima ação |
|---|---|---|---|---|---|---|
| (a preencher conforme execução) |

### Métricas de captação
| Métrica | Valor | Meta | Status |
|---|---|---|---|
| Leads captados (mês) | 0 | 50/mês | — |
| CPL | — | <$50 | — |
| Taxa frios → quentes | — | 20% | — |

---

## Estratégia de Comercialização
**Gerado em:** 2026-06-01
**Leads quentes na data:** Projeção baseada no plano de captação (meta: 10 quentes/mês)

### Qualificação
- Método: Humana (BANT simplificado) — volume baixo, ticket médio-alto, decisão B2B
- Critérios de desqualificação:
  - Sem projeto real em andamento (só curiosidade)
  - Sem authority (não é dono/gerente)
  - Budget abaixo de $300
  - Prazo superior a 6 meses
- Ações: Visita técnica onsite + BANT em 15 min + foto da fachada atual

### Educação
- Método: Conversa direta + conteúdo sob demanda
- Sequência de toques:
  1. Visita onsite com diagnóstico visual + foto before
  2. Envio de proposta com 3 opções (good/better/best) + mockup visual
  3. Follow-up com case de negócio similar em Orlando
  4. Reunião de fechamento com amostras de material
- Materiais: Portfolio impresso, mockups digitais, cases com ROI

### Oferta
- Tipo: Proposta personalizada com 3 tiers
- Estrutura: Good (funcional) / Better (recomendado) / Best (premium com extras)
- Urgência: Slot de instalação limitado + condição de bundle (fachada + interior)

### Fechamento
- Método: Humano (presencial ou call)
- Objeções prováveis:
  - "Tá caro" → ROI em foot traffic + custo por ano de visibilidade
  - "Vou pensar" → Proposta escrita + prazo de validade da condição
  - "Concorrente mais barato" → Comparativo de material + instalação + garantia
  - "Não é agora" → Lock de preço + agendamento futuro
- Ações: Proposta por e-mail com e-signature + follow-up 48h

### Métricas de comercialização
| Métrica | Valor | Meta | Status |
|---|---|---|---|
| Taxa de qualificação | — | 60% | — |
| Taxa de conversão final | — | 30% | — |
| CAC | — | <$300 | — |
| Tempo médio fechamento | — | 14 dias | — |

---

## Relacionamento
**Gerado em:** 2026-06-01
**Clientes ativos:** (a preencher conforme fechamentos)

### Entrega e satisfação
- Modelo: Acompanhada — guiar o cliente na experiência pós-instalação
- Ações:
  - Foto profissional "after" no dia da instalação + envio por WhatsApp
  - Check-in 48h pós-instalação (tudo ok? alguma ajuste?)
  - Check-in 30 dias (satisfação + percepção de resultado)
  - Guia de manutenção impresso entregue na instalação
- TTV alvo: < 48h (cliente vê o resultado imediato na fachada)

### Fidelização
- Mecanismo primário: Hábito — manter contato regular + ser o fornecedor de sinalização pra tudo
- Mecanismo secundário: Valor crescente — conhecimento do negócio do cliente acumulado ao longo do tempo
- Ações:
  - Plano de manutenção ($99/mês) — limpeza, troca de lâmpadas, reparos menores
  - Newsletter mensal com dicas de comunicação visual + seasonal signage tips
  - Desconto de 15% pra clientes recorrentes

### Advocacia
- Incentivada: Programa de referral — 10% de desconto pra ambos (quem indica e quem é indicado)
- Orgânica: Before/after + depoimento em vídeo compartilhado com permissão
- Estratégica: Case study conjunto — cliente ganha visibilidade, FBRSigns ganha prova social

### Métricas de relacionamento
| Métrica | Valor | Meta | Status |
|---|---|---|---|
| Churn mensal | — | <5% | — |
| LTV | — | >$3,000 | — |
| NPS | — | >50 | — |
| Taxa de referral | — | 20% | — |

---

## Histórico de atualizações
| Data | Fase | Ação |
|---|---|---|
| 2026-05-31 | Captação | Scenario criado — análise do report de marketing |
| 2026-06-01 | Comercialização | Estratégia de comercialização definida |
| 2026-06-01 | Relacionamento | Estratégia de relacionamento definida |
