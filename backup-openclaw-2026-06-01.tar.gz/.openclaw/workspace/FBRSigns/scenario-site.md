# Scenario: FBRSigns — Linha de Produtos Online (scenario-site)

## Perfil
- **Tipo:** E-commerce (produtos personalizados / merchandise)
- **Cliente ideal:** Brasileiros nos EUA (comunidade + turistas) e americanos com afinidade por cultura brasileira
- **Mercado:** Nacional (EUA) com foco em Orlando + Central Florida + comunidades brasileiras (NYC, Miami, Boston, Framingham)
- **TAM:** ~1.5M brasileiros nos EUA + turistas brasileiros (~2M/ano)
- **SAM:** ~500K brasileiros engajados com pride/identity products
- **SOM:** 500-2,000 pedidos/mês (fase madura)
- **Estágio:** Planejamento — sem loja online, sem catálogo definido
- **Ticket médio:** $25-75 por pedido
- **Ciclo de vendas:** Impulso (minutos)
- **Tipo de decisão:** B2C — compra emocional (pride, identidade, presente)
- **Data de criação:** 2026-06-01
- **Última atualização:** 2026-06-01

---

## Linha de Produtos Atual

| Produto | Uso | Potencial |
|---|---|---|
| **Camisetas** | Uso casual, pride, presente | ★★★★★ — Top seller em qualquer POD |
| **Uniformes** | Times, empresas, eventos | ★★★★ — B2B recorrente |
| **Canecas** | Presente, escritório, presente | ★★★★★ — Melhor margem, item de gift |
| **Bonés** | Uso casual, pride, presente | ★★★★ — Complemento perfeito |

---

## Produtos Sugeridos — Expansão da Linha

### Tier 1 — Adicionar imediatamente (alto retorno, baixo risco)

| Produto | Por que faz sentido | Margem estimada | Demanda |
|---|---|---|---|
| **Camisetas infantis / baby onesies** | Brasileiros nos EUA compram pros filhos. "Brazilian American Baby" é busca popular. | 30-40% | ★★★★★ |
| **Moletons / Hoodies** | Inverno americano = hoodie. Pride brasileiro em hoodie é top seller no Etsy. | 25-35% | ★★★★★ |
| **Bolsas tote** | Brasileiro ama tote bag. Flag design, frase bicultural. Barato de produzir. | 40-50% | ★★★★ |
| **Adesivos / Stickers** | Ticket baixíssimo ($3-5), margem alta (60%+), impulse buy perfeito. Flag, frases, Christ the Redeemer. | 60-70% | ★★★★★ |
| **Canecas de viagem (travel mugs)** | Brasileiro que dirige nos EUA ama caneca térmica. "Brazilian Fuel" ou flag design. | 30-40% | ★★★★ |
| **Mousepads** | Escritório/home office. Flag brasileira + "Made in Brazil, Working in USA". | 40-50% | ★★★ |
| **Almofadas** | Decoração de casa. Flag design, frases. Item de gift. | 30-40% | ★★★ |

### Tier 2 — Adicionar no mês 2-3 (diferenciação)

| Produto | Por que faz sentido | Margem estimada | Demanda |
|---|---|---|---|
| **Banners / faixas personalizadas** | Sinergia com o negócio de signage! "Feliz Aniversário", "Grand Opening", decoração de festa. | 50-60% | ★★★★ |
| **Placas decorativas** | Sinergia com signage! Placas de parede com frases, flag, mapas. Produto único que conecta os dois negócios. | 50-70% | ★★★★ |
| **Capas de celular** | Todo mundo tem celular. Design brasileiro. Margem boa. | 30-40% | ★★★★ |
| **Squeeze bottles / garrafas** | Fitness + pride brasileiro. "Brazilian Energy". | 30-40% | ★★★ |
| **Pôsteres / wall art** | Cristo Redentor, Ipanema, skyline de São Paulo, flag art. Decoração de quarto/apartamento. | 40-50% | ★★★★ |
| **Agendas / cadernos** | Início do ano escolar americano (Aug/Sep). Design brasileiro. | 30-40% | ★★★ |

### Tier 3 — Produtos sazonais / especiais (alto impacto, demanda pontual)

| Produto | Quando | Por que |
|---|---|---|
| **Camisetas de Copa / Seleção** | Copa América / Copa do Mundo | Demand spike massivo. Brasileiro compra no impulso. |
| **Kit Festa Junina** (bandeirinhas, adesivos, camiseta) | Junho | Produto composto com margem alta. Único no mercado. |
| **Kit Carnaval** (máscara, adesivos, camiseta, bandeira) | Fevereiro-Março | Festividade brasileira mais icônica. |
| **Kit 7 de Setembro** (bandeira, camiseta, boné) | Setembro | Independence Day brasileiro nos EUA. |
| **Kit Natal Brasileiro** (cards, adesivos, camiseta temática) | Dezembro | Fusão cultural: Natal brasileiro nos EUA. |
| **Presente de Mother's Day / Father's Day** | Maio / Junho | "Presente pro pai/mãe que é brasileiro e mora longe." Emotional trigger. |

### Tier 4 — Produtos de valor agregado (sinergia com FBR Inc)

| Produto | Por que |
|---|---|
| **Kit "Brasileiro em Orlando"** — camiseta + caneca + adesivo + guia impresso da cidade | Cruza merch com turismo. Único no mercado. |
| **Coleção "Negócios Brasileiros"** — uniformes e sinalização para empresas brasileiras | Sinergia com FBRSigns! O cliente de signage é o mesmo cliente de uniformes. |
| **Co-branded com ativos FBR** — camiseta "FBR.News" ou "Facebrasil" | Marketing dos ativos de mídia + receita de merch. Win-win. |

---

## Plataformas e Infraestrutura

### Modelos de venda

| Modelo | Plataforma | Margem | Controle | Esforço |
|---|---|---|---|---|
| **Loja própria (Shopify)** | Shopify + Printify/Printful | 30-50% | Total | Médio-alto |
| **Marketplace (Etsy)** | Etsy + Printify | 20-35% | Parcial | Baixo |
| **Marketplace (Amazon)** | Amazon Merch + FBA | 15-25% | Baixo | Baixo |
| **Social commerce (Instagram)** | Instagram Shop + Printify | 30-50% | Total | Médio |

### Recomendação: Shopify + Printify + Etsy

- **Shopify** pra loja própria (controle total, branding, remarketing)
- **Printify** pra fulfillment (melhor margem, catálogo grande)
- **Etsy** como canal adicional (tráfego orgânico de gente buscando "Brazilian American gift")

### Custos

| Item | Custo/mês |
|---|---|
| Shopify (básico) | $39/mês |
| Printify (grátis até 5 designs) | $0 |
| Domínio | $15/ano |
| Canva Pro (designs) | $13/mês |
| Instagram Ads | $200-500/mês |
| Facebook Ads | $200-500/mês |
| **Total** | **$450-1,050/mês** |

---

## Estratégia de Captação (e-commerce)

### Descoberta

| Canal | Ação | Custo |
|---|---|---|
| **Instagram** | Feed 100% em português, designs brasileiros, humor, pride | $0 |
| **Etsy SEO** | Otimizar listings com "Brazilian American gift", "Brazil flag shirt", "Brazilian pride" | $0 |
| **Google Shopping** | Ads pra buscas como "Brazilian t shirt", "Brazil flag hoodie" | $200-400/mês |
| **Facebook groups** | Grupos de brasileiros nos EUA — postar designs sem vender diretamente | $0 |
| **TikTok** | Vídeos curtos de unboxing, "Look at this Brazilian pride shirt", trending audio | $0 |
| **WhatsApp groups** | Catálogo via WhatsApp Business — "Novos designs chegando" | $0 |

### Atenção

| Padrão | Exemplo |
|---|---|
| **Identificação** | "Morar longe do Brasil não significa esquecer de onde veio" |
| **Curiosidade** | "Design que só brasileiro nos EUA entende" |
| **Emoção** | "Presente pra quem morre de saudade do Brasil" |
| **Prova** | "+5.000 brasileiros nos EUA já usam nossas camisetas" |

### Registro

| Modelo | Conversão |
|---|---|
| **Compra direta (impulso)** | Shopify checkout + Apple Pay / Google Pay (friction zero) |
| **Troca de valor** | "Cadastre no email e ganhe 10% off na primeira compra" |
| **Social** | Instagram Shop → compra sem sair do app |

---

## Estratégia de Comercialização (e-commerce)

### Qualificação: Autoprovação
- O produto se qualifica sozinho — preço acessível, visual claro, compra por impulso
- Não precisa de vendedor

### Educação: Conteúdo sob demanda
- Instagram feed = vitrine permanente
- Stories = unboxing, bastidores, "lookbook"
- TikTok = trend riding, humor brasileiro

### Oferta: Direta + Condicionada
- Preço visível, checkout rápido
- Gatilhos: "Frete grátis acima de $50", "Compre 2 ganhe 10% off", "edição limitada"

### Fechamento: Automático
- Checkout Shopify + Apple Pay / Google Pay
- Zero intervenção humana

---

## Estratégia de Relacionamento (e-commerce)

### Entrega
- Print-on-demand: Printify produz e envia direto
- TTV: 3-7 dias (recebe em casa)
- Email de confirmação + tracking automático

### Fidelização
- **Email marketing** — novos designs, sazonalidade, desconto de aniversário
- **Programa de pontos** — cada compra = pontos, pontos = desconto
- **Novos designs mensais** — coleções temáticas (feriados, Copa, Carnaval)

### Advocacia
- **UGC (User Generated Content)** — incentivar clientes a postar foto com a camiseta → repost
- **Hashtag própria** — #FBRSignsStyle ou #BrazilianInUSA
- **Review com foto** — oferecer 10% off na próxima compra por review com foto
- **Referral** — "Indique um amigo, vocês dois ganham $10 de crédito"

---

## Metas (Primeiros 6 meses)

| Métrica | Mês 1 | Mês 3 | Mês 6 |
|---|---|---|---|
| Produtos no catálogo | 20 SKUs | 50 SKUs | 100+ SKUs |
| Pedidos/mês | 30 | 100 | 300-500 |
| Receita/mês | $750-1,500 | $2,500-5,000 | $7,500-15,000 |
| Ticket médio | $30 | $35 | $35-40 |
| CPL | $5-10 | $3-7 | $2-5 |

---

## Sinergia com FBRSigns (signage) e FBR Inc

| Sinergia | Como funciona |
|---|---|
| **Mesma base de clientes** | Quem compra signage do restaurante brasileiro também quer uniformes pros funcionários |
| **Cross-sell** | "Fez a fachada com a gente? Os uniformes pra equipe têm 20% off." |
| **Bundle** | "Pacote Grand Opening: fachada + uniformes + camisetas promocionais" |
| **Ativos de mídia** | Camisetas co-branded com Facebrasil/FBR.News — marketing + receita |
| **Comunidade** | Grupo WhatsApp compartilhado — clientes de signage + clientes de merch |
| **Instagram unificado** | @fbrsigns faz signage e merch — mesma audiência, mesma linguagem |

---

## Investimento (Mês 1)

| Item | Custo |
|---|---|
| Shopify | $39/mês |
| Domínio | $15/ano |
| Printify | $0 (grátis) |
| Canva Pro | $13/mês |
| Design de 20 SKUs iniciais | $0-200 (se contratar designer) |
| Meta Ads (teste) | $200-300/mês |
| **Total estimado** | **$250-550/mês** |

---

*Scenario-site gerado pelo pipeline-fbr. FBR Inc — 1 de junho de 2026.*
