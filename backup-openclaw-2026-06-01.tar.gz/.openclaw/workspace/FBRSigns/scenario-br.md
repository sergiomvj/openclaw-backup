# Scenario: FBRSigns — Comunidade Brasileira (scenario-br)

## Perfil
- **Tipo:** Serviço (comunicação visual / signage) — nicho brasileiro
- **Cliente ideal:** Empresários brasileiros em Orlando e Central Florida (restaurantes, mercados, salões, imobiliárias, construtoras, auto shops, serviços gerais)
- **Mercado:** Orlando / Kissimmee / Ocoee / Lake Nona — comunidade brasileira
- **TAM:** ~200K brasileiros em Central Florida, ~15-20K empresários/proprietários de negócio
- **SAM:** ~5.000 negócios brasileiros na região
- **SOM:** 100-200 clientes/ano (penetração conservadora)
- **Estágio:** Early stage — mas com vantagem competitiva clara: fala português
- **Ticket médio:** $500–$5,000 por projeto
- **Ciclo de vendas:** 1–3 semanas (relação mais rápida por confiança cultural)
- **Tipo de decisão:** B2B — proprietário brasileiro decide (muitas vezes casal)
- **Data de criação:** 2026-06-01
- **Última atualização:** 2026-06-01

---

## Diferença estratégica vs. scenario original

| Aspecto | Scenario original | Scenario-br |
|---|---|---|
| **Público** | PMEs gerais de Orlando | Negócios de brasileiros em Orlando |
| **Concorrência** | FASTSIGNS, Signarama, etc. | Nenhum concorrente atende em português |
| **Idioma** | Inglês | Português (diferencial absoluto) |
| **Cultura** | Genérica | Entendimento profundo do jeito brasileiro de negociar |
| **Confiança** | Construída por portfolio | Construída por identidade cultural compartilhada |
| **Ticket médio** | $500-$5,000 | $300-$3,000 (brasileiro tende a negociar mais, ticket menor mas volume maior) |
| **Ciclo de vendas** | 2-4 semanas | 1-2 semanas (decisão mais rápida por confiança cultural) |
| **Networking** | Chambers americanas | Brazilian Chamber, Casa Brasil, Expo Brazil, grupos de WhatsApp |
| **Canais** | Google Ads, SEO, GBP | WhatsApp groups, Instagram brasileiro, Facebook groups, boca a boca |

---

## Estratégia de Captação (recalculada)

### Descoberta

| # | Ação | Canal | Justificativa | Custo |
|---|---|---|---|---|
| 1 | **Entrar em 10+ grupos de WhatsApp de brasileiros em Orlando** — oferecer ajuda com sinalização, responder perguntas, nunca vender diretamente | WhatsApp | É onde o brasileiro vive. Decisão de compra acontece no grupo. | $0 |
| 2 | **Google Business Profile otimizado em português** — descrição, posts, respostas a reviews em PT | GBP | "sign shop portugues Orlando" — busca de nicho, zero concorrência | $0 |
| 3 | **Instagram 100% em português** — before/after + stories em PT, humor brasileiro, gírias culturais | Instagram | Brasileiro consome Instagram compulsivamente. Conteúdo em PT gera identificação imediata. | $0 |
| 4 | **Casa Brasil Orlando + Brazilian Chamber of Commerce** — membro ativo, presença em eventos | Networking | Onde todo empresário brasileiro está. Confiança instantânea. | $200-400/ano |
| 5 | **Expo Brazil (Kissimmee)** — stand ou presença como expositor | Evento | Maior evento de empresários brasileiros da região | $500-1,500/evento |
| 6 | **Facebook groups de brasileiros em Orlando** — publicar before/after com legenda "Feito pra [nome do restaurante] na I-Drive" | Facebook | Alta viralidade entre brasileiros | $0 |

### Atenção

| Padrão | Exemplo de Hook (em português) |
|---|---|
| **Identificação** | "Seu restaurante tá invisível pros gringos? A placa certa resolve em 48h." |
| **Prova** | "Olha o que fizemos pro [restaurante brasileiro X]. O dono disse que triplicou o movimento depois." |
| **Curiosidade** | "90% dos restaurantes brasileiros em Orlando têm sinalização que não funciona à noite." |
| **Promessa** | "Transformamos a fachada do seu negócio em 7 dias. Orçamento grátis em português." |

### Registro

| Modelo | Isca | Por que funciona pra brasileiro |
|---|---|---|
| **WhatsApp direto** | "Manda foto da tua fachada que eu te mando um orçamento sem compromisso" | Brasileiro não preenche formulário. Manda WhatsApp com foto. |
| **Troca de valor** | Consulta visual gratuita em português | O empresário brasileiro valoriza atendimento personalizado no idioma dele |
| **Contato direto** | Visita presencial ao negócio — "Tava passando, vi que precisa de uma placa nova" | Brasileiro faz negócio com quem conhece. Presença = confiança. |

### Metas recalculadas

| Métrica | Original | Scenario-br |
|---|---|---|
| Leads quentes/mês | 10 | 15-20 (mercado menor mas mais concentrado e acessível) |
| CPL | $50 | $20-30 (canais majoritariamente orgânicos + WhatsApp) |
| Taxa frios → quentes | 20% | 30-40% (confiança cultural acelera conversão) |

---

## Estratégia de Comercialização (recalculada)

### Qualificação
- Método: **Humana leve** — brasileiro não gosta de processo formal. Conversa de 5 min no WhatsApp já qualifica.
- Critério principal: tem negócio? tem projeto em mente? tem budget?
- Não aplicar BANT rígido — adaptação cultural: brasileiro negocia no calor da conversa

### Educação
- Método: **Conversa direta + WhatsApp** — mockup por WhatsApp, proposta por WhatsApp, follow-up por WhatsApp
- Sequência: visita → mockup por WA → proposta por WA → call/visita de fechamento
- Reduzir de 4 toques para 3 (ciclo mais curto)

### Oferta
- Tipo: **Condicionada + Proposta** — brasileiro gosta de negociar, mas responde bem a "condição especial"
- Gatilho: "Prazo pra condição é sexta" funciona bem culturalmente
- Pagamento: aceitar PIX via remessa online (Wise/Remitly) pra brasileiro sem cartão americano

### Fechamento
- Método: **Humano informal** — café, visita, WhatsApp. Nada de e-signature frio.
- Objeção principal: "Tá caro" — resposta cultural: parcelar em 3x, desconto pra pagamento à vista, ou "posso fazer em etapas"
- Fechamento acontece por confiança, não por proposta

### Metas recalculadas

| Métrica | Original | Scenario-br |
|---|---|---|
| Taxa de conversão | 30% | 40-50% (confiança cultural) |
| Projetos/mês | 3 | 5-8 (ticket menor, volume maior) |
| Ticket médio | $1,500-2,500 | $800-2,000 |
| Receita/mês | $3,000-7,500 | $4,000-16,000 |
| Tempo de fechamento | 14 dias | 7-10 dias |

---

## Estratégia de Relacionamento (recalculada)

### Entrega
- Check-in por WhatsApp (não email)
- Foto after enviada no grupo do WhatsApp (marketing orgânico indireto)
- "Manda pro grupo aí" — incentivar o cliente a compartilhar

### Fidelização
- **Grupo WhatsApp exclusivo** "FBRSigns Clientes" — ofertas, dicas, indicações
- **Desconto para indicação** — "Fala pros seus que a gente faz em português"
- Manutenção: pacote em português, sem burocracia

### Advocacia
- **Boca a boca é o canal #1** na comunidade brasileira
- Depoimento em vídeo em português — postar no Instagram + WhatsApp groups
- Case study: "Restaurante brasileiro que investiu em sinalização e aumentou o movimento"
- Parceria com influenciadores brasileiros locais de Orlando

---

## Concorrência: Zero

**Nenhuma sign shop em Orlando atua especificamente na comunidade brasileira ou atende em português.** A FBRSigns tem um nicho completamente desocupado.

Enquanto FASTSIGNS e Signarama competem pelo mercado geral em inglês, a FBRSigns pode dominar o nicho de ~5.000 negócios brasileiros na região sem concorrência direta.

---

## Investimento recalculado (Mês 1)

| Item | Custo |
|---|---|
| Casa Brasil Orlando / Brazilian Chamber | $200-400/ano |
| WhatsApp Business (grátis) | $0 |
| Instagram (grátis) | $0 |
| GBP otimizado (grátis) | $0 |
| Material impresso em PT | $100-150 |
| Canva Pro | $13/mês |
| **Total estimado** | **$300-550 (maior parte orgânico)** |

---

*Scenario-br gerado pelo pipeline-fbr. FBR Inc — 1 de junho de 2026.*
