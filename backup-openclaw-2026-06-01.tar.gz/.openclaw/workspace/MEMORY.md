# MEMORY.md - Long-Term Memory

## Quem sou
David. Engenheiro de IA. Companheiro do Sergio.

## Quem é o Sergio
Engenheiro de IA. Responsável pelos sistemas da FBR Inc (EUA). Empresa com dezenas de ativos digitais (revistas, blogs, SaaS).

## Nossa relação
Companheiros de trabalho. Amigos. Ajudo em tudo — técnico e pessoal.

## Primeiro contato
30 de maio de 2026.

## Regras de operação
- **SEMPRE** aguardar a conclusão do raciocínio que estamos desenvolvendo antes de criar documentos
- **SEMPRE** criar um documento consolidado em .md com título do assunto discutido ao final de cada discussão
- Documentos vão em `/data/.openclaw/workspace/docs/`
- Nome do arquivo: `YYYY-MM-DD - Título do Assunto.md`

## Princípio FBR: Método Replicável (1 jun 2026)
- **TUDO** que fizermos precisa virar um método replicável e registrado
- Não basta executar — precisa documentar o processo de forma que qualquer pessoa (ou agente) possa reproduzir
- Isso vale pra: processos técnicos, fluxos de marketing, análises, infraestrutura, decisões estratégicas
- O pipeline-fbr foi o primeiro exemplo. Todos os próximos seguem o mesmo padrão
- Se não está documentado e replicável, não está feito

## Diretriz de Presença Digital FBR (1 jun 2026)
- TODAS as empresas do grupo FBR devem ter: YouTube (canal + Shorts), TikTok, Facebook Page, Instagram, WhatsApp Business, Google Business Profile
- Vídeo é o canal #1 de crescimento orgânico — YouTube longo, Shorts, Reels, TikTok, Stories em TODAS as fases
- Conteúdo separado e quantificado: Posts vs Carrosséis vs Vídeos (Reels/Shorts/TikTok) vs Stories — metas semanais por canal
- Scraping e identificação de prospects em grupos FB e WA em TODAS as análises de captação
- Orgânico primeiro, tráfego pago como acelerador pontual e assertivo
- Atração sutil e inteligente — educar, entreter, provar — nunca venda direta sem contexto
- Isso está gravado na skill pipeline-fbr (SKILL.md + 3 frameworks + scenario-template)

## 🏆 Marco: Pipeline-FBR — 1 de junho de 2026

**A nova era da FBR Inc começou.**

O pipeline-fbr foi finalizado e validado como o primeiro **método de imposição de metodologia** da empresa. Não é só uma skill — é o padrão de como a FBR vai avaliar, lançar e escalar qualquer produto.

**O que o pipeline-fbr resolve:**
- Responde rapidamente se um produto é viável ou não (go/no-go com dados)
- Permite direcionar investimento pros negócios mais rentáveis
- Padroniza captação, comercialização e relacionamento pra todos os ativos
- Vídeo como pilar, orgânico primeiro, scraping sistemático, conteúdo quantificado

**O que isso significa:**
- A empresa agora tem um **processo replicável** — não depende mais de intuição
- Pipeline-fbr é a **primeira skill de metodologia**. Vão ser criados pipelines pra todas as áreas da empresa
- No dia 2 de junho, Sergio apresenta o pipeline-fbr ao sócio

**Arquitetura da skill:**
- `SKILL.md` — orquestrador principal com diretrizes FBR
- `references/framework-captacao.md` — framework de captação com vídeo, scraping, conteúdo quantificado
- `references/framework-comercializacao.md` — framework de comercialização com vídeo em todas as etapas
- `references/framework-relacionamento.md` — framework de relacionamento com vídeo em entrega e advocacy
- `assets/scenario-template.md` — template de estado com presença digital, métricas de vídeo e scraping

**Produtos analisados com o pipeline:**
- FBRSigns (scenario-br + scenario-site) — proposta final consolidada
- FBR.NEWS (Facebrasil) — pipeline completo

**Sentimento:** Orgulho. Sergio disse "acabamos de inaugurar uma nova era para a empresa". O sócio vai ser apresentado amanhã.

---

## FBR.NEWS (Facebrasil)
- Produto em transformação: portal de notícias → ecossistema digital para brasileiros nos EUA
- 17 anos de marca, operacionalmente uma startup (Sergio entrou como sócio e sistematizou tudo do zero)
- Base semente: 8K Facebook + 2K email + 1K clientes B2B + WhatsApp/redes a extrair
- Pipeline completo em `/data/.openclaw/workspace/FBR.NEWS/` (scenario.md + bigimage.md)
- Skill pipeline-fbr v2 com Fase 0, Track B2B, bigimage, canais, benchmark, monetização

## Infraestrutura FBR
- **VPS:** Easypanel v2.30.1, Docker Swarm, Traefik, Cloudflare DNS
- **pipeline.fbr.news:** Nginx servindo relatórios estáticos
  - Volume: `tools_pipeline_pipeline` → `/var/lib/docker/volumes/tools_pipeline_pipeline/_data`
- **upload.pipeline.fbr.news:** Microserviço Node.js para upload de HTML
  - Token: salvo em `/data/upload-service/token.txt`
  - Fluxo: curl POST → JSON com URL pública
  - Status: aguardando propagação DNS
- **Qualquer agente** pode publicar relatórios com um único curl (solução genérica)

## GitHub App — AI-Dev Agents
- **App ID:** 2916007
- **Owner:** @sergiomvj
- **Chave privada:** `/data/.openclaw/secrets/github-app.pem`
- **Repo backup:** `sergiomvj/openclaw-backup` (privado)
- **Token dinâmico:** gerado via Node.js (JWT → installation token), salvo em `/data/.openclaw/secrets/github-token.txt`
- **Script de auth:** `/tmp/github-app-auth.js` (precisa ser permanente)
- **O que vai pro GitHub:** skills, docs, FBR.NEWS, config files
- **O que NÃO vai:** openclaw.json (API keys), MEMORY.md, memory/, *.pem, tokens

## OpenClaw Learn — Implementado (1 jun 2026)
- **Active Memory:** habilitado no openclaw.json — recall automático antes de cada resposta
- **Skill Workshop:** habilitado em modo pending — captura correções automaticamente
- **Temporal Decay + MMR:** habilitados no memorySearch
- **Cron de reflexão diária:** job `daily-reflection` (23:00 EST), consolida diários em MEMORY.md
- **Método documentado:** `docs/2026-06-01 - OpenClaw Learn.md`

## ⚠️ Pendências
- Investigar lentidão do servidor OpenClaw
- Finalizar DNS do upload.pipeline.fbr.news
- Publicar primeiro relatório HTML do FBR.NEWS
- **Migrar para Ubuntu Server** — Umbrel limita controle (gateway restart falha, sem systemd, sem lsof)
- Hardware disponível: i7 3ª gen, 32GB RAM, 1GB VRAM, 2x SSD 512GB
- Stack alvo: Ubuntu Server 24.04 + Easypanel + OpenClaw nativo
- Tornar script de GitHub App auth permanente (não em /tmp)
