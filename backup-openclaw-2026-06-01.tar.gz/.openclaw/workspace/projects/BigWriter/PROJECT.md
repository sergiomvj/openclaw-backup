# BigWriter — Projeto Conceitual

> **Versão:** 1.0  
> **Data:** 31 de Maio de 2026  
> **Autor:** David ⚡ para Sergio  
> **Status:** Conceitual — Aprovado para desenvolvimento  

---

## 1. Visão Geral

**BigWriter** é um sistema de produção automatizada de conteúdo textual, projetado para atender as necessidades da **FBR Inc** e seus ativos digitais (revistas, blogs, sistemas SaaS).

O sistema opera 100% em batch, cobrindo todo o ciclo: planejamento editorial → produção de textos → revisão por IA → spool de publicação.

### Objetivo

Produzir artigos de alta qualidade em português (e futuramente multi-idioma) de forma automatizada, escalável e sem intervenção humana contínua.

### Filosofia

- **Batch-first:** Nenhuma interação em tempo real. Produz enquanto você dorme.
- **Multi-pass:** Texto gerado em etapas, cada uma refinando a anterior.
- **Revisão por segunda IA:** Garantia de qualidade independente do produtor.
- **Spool de publicação:** Artigos prontos aguardam agendamento ou aprovação.

---

## 2. Hardware Dedicado

### 2.1 — MiniPC Especificado

| Componente | Especificação |
|---|---|
| **Processador** | Intel Core i7 8ª geração |
| **RAM** | 20 GB DDR4 |
| **Disco principal** | SSD 512 GB (NVMe ou SATA) |
| **Disco secundário** | HD 512 GB |
| **Rede** | RJ45 Gigabit nativa |
| **GPU** | Intel UHD integrada (sem GPU dedicada) |

### 2.2 — Alocação de Recursos

| Recurso | Uso estimado | Disponível | Margem |
|---|---|---|---|
| **RAM** | ~16 GB (modelo + sistema + queue) | 20 GB | 4 GB livres |
| **CPU** | ~60-80% durante produção batch | 4 cores / 8 threads | Suficiente |
| **SSD** | ~50 GB (sistema + modelos + banco) | 512 GB | 462 GB livres |
| **HD** | Artigos gerados, logs, backups | 512 GB | Quase tudo livre |

### 2.3 — Sistema Operacional

- **Recomendação:** Ubuntu Server 24.04 LTS
- Leve, estável, suporte longo prazo, compatibilidade total com Ollama e Python
- Sem GUI — tudo via terminal e dashboard web

---

## 3. Stack Técnica

### 3.1 — LLMs

| Papel | Modelo | Quantização | RAM | Motivo |
|---|---|---|---|---|
| **Produtor** | Gemma 4 26B A4B (MoE) | Q8_0 | ~14 GB | Alta qualidade de texto, MoE = rápido, Q8 = mínima perda |
| **Revisor** | Qwen 2.5 7B | Q6_K | ~6 GB | Leve, rápido, excelente em PT-BR, bom para análise crítica |

**Nota:** Os dois modelos não rodam simultaneamente. O sistema carrega um por vez conforme o estágio do pipeline. RAM total necessária: ~14 GB (produtor) ou ~6 GB (revisor), nunca ambos.

### 3.2 — Infraestrutura

| Componente | Tecnologia | Função |
|---|---|---|
| **Runtime LLM** | Ollama | Serve modelos locais via API |
| **Queue / Broker** | Redis | Fila de jobs e comunicação entre workers |
| **Workers** | Celery (Python) | Processamento batch dos artigos |
| **API** | FastAPI | Interface REST para dashboard e integrações |
| **Banco de dados** | SQLite (inicial) → PostgreSQL (produção) | Briefings, artigos, histórico |
| **Scheduler** | Celery Beat | Agendamento do planejador editorial |
| **Frontend** | Streamlit (MVP) → React (produção) | Dashboard de monitoramento |

### 3.3 — Diagrama da Stack

```
┌─────────────────────────────────────────────────────────┐
│                    MiniPC BigWriter                     │
│              Ubuntu Server 24.04 LTS                    │
│                                                         │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────────┐ │
│  │  Ollama   │  │  Redis   │  │   SQLite / Postgres   │ │
│  │  :11434   │  │  :6379   │  │      :5432            │ │
│  └─────┬────┘  └────┬─────┘  └───────────┬───────────┘ │
│        │            │                    │              │
│  ┌─────▼────────────▼────────────────────▼───────────┐  │
│  │              FastAPI (:8000)                       │  │
│  │                                                    │  │
│  │   /api/briefings    — CRUD de briefings           │  │
│  │   /api/articles     — Status dos artigos          │  │
│  │   /api/spool        — Spool de publicação         │  │
│  │   /api/pipeline     — Controle do pipeline        │  │
│  │   /api/dashboard    — Métricas e monitoramento    │  │
│  └────────────────────┬──────────────────────────────┘  │
│                       │                                 │
│  ┌────────────────────▼──────────────────────────────┐  │
│  │            Celery Workers                          │  │
│  │                                                    │  │
│  │   Worker Planejamento  → Gera briefings           │  │
│  │   Worker Produção     → Gemma 4 → rascunho       │  │
│  │   Worker Revisão      → Qwen 2.5 → score         │  │
│  │   Worker Publicação   → Push para CMS             │  │
│  └───────────────────────────────────────────────────┘  │
│                                                         │
│  ┌───────────────────────────────────────────────────┐  │
│  │   Celery Beat (Scheduler)                         │  │
│  │   "Toda segunda 08:00 → rodar planejador"        │  │
│  └───────────────────────────────────────────────────┘  │
│                                                         │
│  ┌───────────────────────────────────────────────────┐  │
│  │   Dashboard (Streamlit / React) :3000             │  │
│  │   Visualização e aprovação de artigos             │  │
│  └───────────────────────────────────────────────────┘  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 4. Pipeline de Produção

### 4.1 — Visão Geral

```
  PLANEJAMENTO       PRODUÇÃO           REVISÃO           PUBLICAÇÃO
  (Automático)       (Batch/Gemma 4)    (Batch/Qwen)      (Spool)

  Calendário    →    Rascunho      →    Score 8.5+   →    Agendado
  Editorial          Refinamento        Aprovado?          Publicado
  Briefings          SEO                Reprovado→volta    Aprov. Humana?
```

### 4.2 — Stage 1: Planejamento

**Responsável:** Worker de Planejamento + Celery Beat

**Execução:** Semanal (segundas-feiras) ou sob demanda

**Processo:**
1. Lê calendário editorial de cada ativo FBR
2. Consulta trending topics e keywords relevantes
3. Gera briefings em JSON com estrutura definida
4. Empilha briefings na fila de produção

**Output: Briefing**

```json
{
  "id": "bw_2026_0601_001",
  "ativo": "revista-tech-br.com",
  "tipo": "artigo",
  "prioridade": "normal",
  "titulo_proposto": "5 tendências de IA que vão transformar 2027",
  "keywords": ["IA", "inteligência artificial", "tendências", "2027"],
  "tom_voz": "informativo-profissional",
  "publico_alvo": "profissionais de tecnologia",
  "tamanho_palavras": {"min": 1500, "max": 2000},
  "estrutura": [
    "introdução_cativante",
    "secao_tendencia_1",
    "secao_tendencia_2",
    "secao_tendencia_3",
    "secao_tendencia_4",
    "secao_tendencia_5",
    "conclusao_cta"
  ],
  "cta": "Inscreva-se na newsletter",
  "meta_description": "...",
  "data_publicacao": "2026-06-03T09:00:00",
  "plataforma": "wordpress",
  "categoria": "Inteligência Artificial",
  "tags": ["IA", "futuro", "tecnologia"],
  "status": "queued_production"
}
```

### 4.3 — Stage 2: Produção (Gemma 4)

**Responsável:** Worker de Produção

**Modelo:** Gemma 4 26B A4B Q8 via Ollama

**Processo por artigo (multi-pass):**

| Passo | Prompt | Objetivo |
|---|---|---|
| **Pass 1 — Estrutura** | "Gere o esqueleto do artigo: títulos, subtítulos, pontos-chave" | Organizar ideias |
| **Pass 2 — Rascunho** | "Escreva o artigo completo seguindo a estrutura e o briefing" | Texto bruto |
| **Pass 3 — Expansão** | "Expanda cada seção com exemplos, dados e contexto" | Profundidade |
| **Pass 4 — SEO** | "Otimize para SEO: keywords naturais, headings, meta description" | Ranqueamento |
| **Pass 5 — Tom de Voz** | "Ajuste o tom para [identidade editorial do ativo]" | Consistência |

**Cada passo recebe o output do anterior como contexto.**

**Tempo estimado por artigo:** 5-10 minutos (5 passes × 1-2 min cada)

**Output: Draft**

```json
{
  "id": "bw_2026_0601_001",
  "status": "draft_complete",
  "texto": "...(artigo completo em markdown)...",
  "word_count": 1847,
  "seo_score_estimado": 7.8,
  "passes": {
    "estrutura": {"concluido": true, "tempo_ms": 45000},
    "rascunho": {"concluido": true, "tempo_ms": 120000},
    "expansao": {"concluido": true, "tempo_ms": 95000},
    "seo": {"concluido": true, "tempo_ms": 55000},
    "tom_voz": {"concluido": true, "tempo_ms": 60000}
  },
  "total_tempo_producao_ms": 375000,
  "modelo": "gemma4:26b-a4b-q8",
  "tokens_gerados": 4250,
  "timestamp_conclusao": "2026-06-01T03:15:00Z"
}
```

### 4.4 — Stage 3: Revisão (Qwen 2.5)

**Responsável:** Worker de Revisão

**Modelo:** Qwen 2.5 7B Q6 via Ollama

**Critérios de avaliação:**

| Critério | Peso | Descrição |
|---|---|---|
| **Gramática** | 15% | Erros ortográficos, pontuação, concordância |
| **Coerência** | 20% | Fluxo lógico, transições entre seções |
| **Aderência ao briefing** | 20% | Cumpriu tema, estrutura, tom, público-alvo |
| **SEO** | 15% | Keywords naturais, headings, meta description |
| **Originalidade** | 15% | Não repetitivo, sem frases genéricas de IA |
| **Legibilidade** | 15% | Frases curtas, parágrafos bem divididos |

**Lógica de decisão:**

```
Score ≥ 9.0  →  ✅ APROVADO — segue para spool
Score 8.0-8.9 →  ✅ APROVADO COM RECOMENDAÇÕES — segue com notas
Score 7.0-7.9 →  🔁 REVISÃO — volta pra produção com correções específicas
Score < 7.0   →  🔁 REFAZER — volta pro rascunho com instruções detalhadas
```

**Máximo de tentativas por artigo:** 3 (evita loop infinito)

**Output: Review**

```json
{
  "id": "bw_2026_0601_001",
  "status": "approved",
  "review": {
    "score_geral": 8.7,
    "gramatica": {"score": 9.5, "notas": "Texto impecável"},
    "coerencia": {"score": 8.8, "notas": "Boa transição entre seções 3 e 4"},
    "aderencia_briefing": {"score": 8.5, "notas": "CTA poderia ser mais natural"},
    "seo": {"score": 8.2, "notas": "Keyword principal bem distribuída. Meta description ok."},
    "originalidade": {"score": 8.9, "notas": "Exemplos únicos, sem clichês"},
    "legibilidade": {"score": 8.7, "notas": "Parágrafos curtos, leitura fluida"},
    "veredicto": "APROVADO",
    "recomendacoes": ["Ajustar CTA final para soar menos promocional"],
    "revisor_modelo": "qwen2.5:7b-q6",
    "timestamp": "2026-06-01T03:22:00Z"
  }
}
```

### 4.5 — Stage 4: Spool de Publicação

**Responsável:** Worker de Publicação

**Modos de operação por ativo:**

| Modo | Descrição |
|---|---|
| **AUTO** | Publica automaticamente na data/hora agendada |
| **SEMI** | Notifica responsável, aguarda aprovação no dashboard |
| **MANUAL** | Artigo fica no spool até aprovação manual |

**Integrações com CMS:**
- WordPress (REST API / WP-JSON)
- Ghost (Admin API)
- Custom APIs dos SaaS da FBR

**Output: Publicação**

```json
{
  "id": "bw_2026_0601_001",
  "status": "published",
  "publicacao": {
    "plataforma": "wordpress",
    "url": "https://revista-tech-br.com/5-tendencias-ia-2027",
    "post_id": 4521,
    "data_publicacao": "2026-06-03T09:00:00Z",
    "modo": "semi",
    "aprovado_por": "sergio",
    "timestamp_aprovacao": "2026-06-02T14:30:00Z",
    "timestamp_publicacao": "2026-06-03T09:00:00Z"
  }
}
```

---

## 5. Banco de Dados — Schema

### 5.1 — Entidades Principais

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│     ATIVOS      │     │   BRIEFINGS     │     │    ARTIGOS      │
├─────────────────┤     ├─────────────────┤     ├─────────────────┤
│ id              │────▶│ id              │────▶│ id              │
│ nome            │     │ ativo_id (FK)   │     │ briefing_id(FK) │
│ dominio         │     │ titulo          │     │ status          │
│ plataforma      │     │ keywords        │     │ texto_draft     │
│ tom_voz         │     │ tom_voz         │     │ texto_final     │
│ publico_alvo    │     │ estrutura       │     │ word_count      │
│ modo_publicacao │     │ tamanho         │     │ passes_json     │
│ categoria       │     │ data_alvo       │     │ seo_score       │
│ url_api         │     │ status          │     │ review_json     │
│ api_key         │     │ created_at      │     │ tentativas      │
│ created_at      │     │                 │     │ created_at      │
└─────────────────┘     └─────────────────┘     │ updated_at      │
                                                └────────┬────────┘
                                                         │
┌─────────────────┐     ┌─────────────────┐              │
│  TOM_DE_VOZ     │     │  PUBLICACOES    │              │
├─────────────────┤     ├─────────────────┤              │
│ id              │     │ id              │              │
│ ativo_id (FK)   │     │ artigo_id (FK)  │◀─────────────┘
│ nome            │     │ plataforma      │
│ descricao       │     │ url             │
│ instrucoes      │     │ post_id         │
│ exemplos        │     │ data_agendada   │
│ proibicoes      │     │ data_publicada  │
│ created_at      │     │ modo            │
└─────────────────┘     │ aprovado_por    │
                        │ status          │
                        └─────────────────┘
```

### 5.2 — Status do Artigo (State Machine)

```
                    ┌──────────────────────┐
                    │                      │
                    ▼                      │
  queued_production ──▶ in_production ──▶ draft_complete ──▶ in_review
                          ▲                                      │
                          │                                      ▼
                     rework_needed ◀──────────────────── review_complete
                          │                                      │
                          │                                      ▼
                          │                              approved ──▶ queued_publish
                          │                                              │
                          │                                              ▼
                          │                                         published
                          │                                              │
                          └──────────────────────────────────────── failed
```

---

## 6. Identidade Editorial

### 6.1 — Tom de Voz por Ativo

Cada ativo FBR pode ter seu próprio tom de voz, armazenado como configuração:

```json
{
  "ativo": "revista-tech-br.com",
  "tom_de_voz": {
    "nome": "Tech Journal Brasil",
    "descricao": "Informativo mas acessível. Fala com profissionais de tecnologia que querem se manter atualizados sem jargão excessivo.",
    "instrucoes": [
      "Use segunda pessoa (você) para engajar",
      "Evite termos em inglês quando existe equivalente em português",
      "Sempre inclua exemplos práticos",
      "Parágrafos curtos (3-4 frases máximo)",
      "Cada seção deve ter um takeaway claro"
    ],
    "proibicoes": [
      "Não use 'No mundo de hoje...' ou 'Na era digital...'",
      "Não repita a mesma ideia com palavras diferentes",
      "Não use listas genéricas sem contexto",
      "Evite superlativos excessivos ('incrível', 'revolucionário')"
    ],
    "exemplos_bons": [
      "A nova versão do framework reduz o tempo de build em 40% — e isso muda o jogo para equipes com CI/CD agressivo.",
      "Se você ainda usa a versão 2.x, está na hora de planejar a migração. A 3.x não é só uma atualização, é outra arquitetura."
    ],
    "exemplos_ruins": [
      "A inteligência artificial está revolucionando o mundo como nunca antes visto na história da humanidade.",
      "Neste artigo vamos explorar as maravilhas da tecnologia que está transformando tudo ao nosso redor."
    ]
  }
}
```

### 6.2 — Templates de Prompt

Cada estágio do pipeline usa um template de prompt que injeta o briefing, tom de voz, e contexto:

**Template de Rascunho:**
```
Você é um redator profissional da publicação "{ativo_nome}".

TOM DE VOZ:
{tom_de_voz_instrucoes}

PROIBIÇÕES:
{tom_de_voz_proibicoes}

BRIEFING:
Título: {titulo}
Público: {publico_alvo}
Keywords: {keywords}
Tamanho: {tamanho_min}-{tamanho_max} palavras

ESTRUTURA:
{estrutura}

Escreva o artigo completo em markdown. Siga a estrutura. Use {tom_de_voz_nome}.
```

**Template de Revisão:**
```
Você é um editor-chefe revisando um artigo para a publicação "{ativo_nome}".

Avalie o texto abaixo nos seguintes critérios (0-10):
1. Gramática (15%)
2. Coerência (20%)
3. Aderência ao briefing (20%)
4. SEO (15%)
5. Originalidade (15%)
6. Legibilidade (15%)

BRIEFING ORIGINAL:
{briefing_json}

TOM DE VOZ:
{tom_de_voz}

ARTIGO:
{texto}

Responda em JSON com: score para cada critério, score geral, veredicto (APROVADO/APROVADO_COM_NOTAS/REVISAO/REFAZER), e recomendações específicas.
```

---

## 7. Dashboard

### 7.1 — Funcionalidades

| Seção | Função |
|---|---|
| **Visão Geral** | Métricas: artigos na fila, em produção, aprovados, publicados |
| **Briefings** | CRUD de briefings, calendário editorial |
| **Produção** | Artigos em cada estágio, tempo estimado, logs |
| **Spool** | Artigos prontos para publicação, aprovação |
| **Histórico** | Artigos publicados, scores, performance |
| **Ativos** | Configuração de cada ativo FBR (tom de voz, plataforma, modo) |
| **Configuração** | Modelos, horários, templates |

### 7.2 — Wireframe (MVP)

```
┌─────────────────────────────────────────────────────────┐
│  BigWriter                    [Ativos ▾]  [⚙️ Config]   │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────┐  │
│  │ 📋 12    │  │ ✍️ 3     │  │ ✅ 8     │  │ 📤 45  │  │
│  │ Na Fila  │  │ Produz.  │  │ Aprovad. │  │ Public. │  │
│  └──────────┘  └──────────┘  └──────────┘  └────────┘  │
│                                                         │
│  ── Artigos em Produção ──────────────────────────────  │
│                                                         │
│  🔄 5 tendências de IA para 2027         revista-tech  │
│     Rascunho: ████████░░ 80%  |  Passo 4/5: SEO        │
│                                                         │
│  🔄 Como migrar para Python 3.13          blog-dev-br  │
│     Rascunho: ███░░░░░░░ 30%  |  Passo 2/5: Rascunho   │
│                                                         │
│  ✅ Review: Guia de Kubernetes para iniciantes           │
│     Score: 8.9 | Aguardando aprovação                   │
│     [Aprovar] [Rejeitar] [Editar]                       │
│                                                         │
│  ── Próximos Agendados ──────────────────────────────   │
│                                                         │
│  📅 03/06 09:00 - 5 tendências IA     revista-tech     │
│  📅 03/06 14:00 - Python 3.13         blog-dev-br      │
│  📅 04/06 10:00 - Kubernetes guide     devops-hub       │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 8. Operação Batch

### 8.1 — Cronograma Típico

| Horário | Evento | Detalhe |
|---|---|---|
| **Seg 06:00** | Planejamento semanal | Gera briefings para todos os ativos |
| **Seg 06:30** | Início da produção batch | Workers processam fila de briefings |
| **Ter 02:00** | Revisão batch | Revisor processa todos os drafts |
| **Ter 06:00** | Artigos reprovados voltam | Máximo 3 tentativas |
| **Qua 02:00** | Segunda rodada de revisão | Aprova os reprocessados |
| **Qui 08:00** | Notificação semanal | Dashboard mostra status de tudo |
| **Contínuo** | Publicação agendada | Cada artigo publica na data definida |

### 8.2 — Capacidade Estimada

| Métrica | Estimativa |
|---|---|
| **Artigos por dia (produção)** | 20-30 artigos (batch noturno, 8h) |
| **Artigos por semana** | 100-150 |
| **Tempo por artigo (produção)** | 5-10 minutos |
| **Tempo por artigo (revisão)** | 1-3 minutos |
| **Throughput total** | ~150 artigos/semana com folga |

---

## 9. Estrutura do Projeto

```
bigwriter/
├── README.md
├── pyproject.toml
├── .env.example
│
├── bigwriter/
│   ├── __init__.py
│   ├── config.py              # Configurações centralizadas
│   ├── models/
│   │   ├── __init__.py
│   │   ├── database.py        # Conexão e setup
│   │   ├── ativo.py           # Model: Ativo
│   │   ├── briefing.py        # Model: Briefing
│   │   ├── artigo.py          # Model: Artigo
│   │   └── publicacao.py      # Model: Publicacao
│   │
│   ├── pipeline/
│   │   ├── __init__.py
│   │   ├── planejamento.py    # Stage 1: Geração de briefings
│   │   ├── producao.py        # Stage 2: Multi-pass com Gemma 4
│   │   ├── revisao.py         # Stage 3: Revisão com Qwen 2.5
│   │   └── publicacao.py      # Stage 4: Push para CMS
│   │
│   ├── llm/
│   │   ├── __init__.py
│   │   ├── ollama_client.py   # Cliente Ollama (API calls)
│   │   ├── prompts.py         # Templates de prompt
│   │   └── model_manager.py   # Swap de modelos (produtor/revisor)
│   │
│   ├── workers/
│   │   ├── __init__.py
│   │   ├── celery_app.py      # Config Celery
│   │   ├── worker_planejar.py # Task: planejamento
│   │   ├── worker_produzir.py # Task: produção
│   │   ├── worker_revisar.py  # Task: revisão
│   │   └── worker_publicar.py # Task: publicação
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   ├── main.py            # FastAPI app
│   │   ├── routes/
│   │   │   ├── briefings.py
│   │   │   ├── artigos.py
│   │   │   ├── spool.py
│   │   │   ├── ativos.py
│   │   │   └── dashboard.py
│   │   └── schemas.py         # Pydantic models
│   │
│   ├── cms/
│   │   ├── __init__.py
│   │   ├── wordpress.py       # Integração WordPress
│   │   ├── ghost.py           # Integração Ghost
│   │   └── base.py            # Interface CMS abstrata
│   │
│   └── dashboard/
│       ├── app.py             # Streamlit app
│       └── components/
│           ├── overview.py
│           ├── producao.py
│           └── spool.py
│
├── data/
│   ├── briefings/             # Briefings JSON
│   ├── artigos/               # Artigos gerados
│   └── templates/             # Templates de prompt
│
├── tests/
│   ├── test_pipeline.py
│   ├── test_llm.py
│   └── test_workers.py
│
└── scripts/
    ├── setup.sh               # Setup inicial do servidor
    ├── install_ollama.sh      # Instalar Ollama + modelos
    └── run_batch.sh           # Executar batch manual
```

---

## 10. Roadmap de Desenvolvimento

### Fase 1 — MVP (2-3 semanas)

- [ ] Setup do MiniPC (Ubuntu Server + Ollama + modelos)
- [ ] Pipeline básico: produção → revisão → output em arquivo
- [ ] Briefings manuais (JSON hardcoded)
- [ ] Sem queue, sem banco — prova de conceito funcional
- [ ] 1 ativo de teste

**Entregável:** Artigo gerado, revisado e salvo em disco.

### Fase 2 — Pipeline Completo (2-3 semanas)

- [ ] Redis + Celery para fila
- [ ] SQLite para persistência
- [ ] API FastAPI
- [ ] State machine de status
- [ ] Templates de prompt configuráveis por ativo
- [ ] Tom de voz por ativo
- [ ] 3-5 ativos configurados

**Entregável:** Pipeline batch completo, 100% automatizado.

### Fase 3 — Dashboard + Publicação (2 semanas)

- [ ] Dashboard Streamlit
- [ ] Integração WordPress (primeiro CMS)
- [ ] Spool de publicação com modos (AUTO/SEMI/MANUAL)
- [ ] Notificações (email ou Telegram)

**Entregável:** Sistema end-to-end, do briefing à publicação.

### Fase 4 — Escala (contínuo)

- [ ] Migrar para PostgreSQL
- [ ] Dashboard React
- [ ] Planejamento automático (trending topics → briefings)
- [ ] Multi-idioma (PT + EN + ES)
- [ ] Analytics de performance
- [ ] A/B testing de títulos
- [ ] Integração com mais CMS
- [ ] API pública para ativos externos

---

## 11. Custos

### 11.1 — Hardware (já adquirido)

| Item | Custo |
|---|---|
| MiniPC i7 8ª gen + 20GB + SSD 512GB | Já possui |
| **Total** | **R$ 0** |

### 11.2 — Software

| Item | Custo |
|---|---|
| Ubuntu Server | Gratuito |
| Ollama | Gratuito (open source) |
| Gemma 4 26B A4B | Gratuito (Apache 2.0) |
| Qwen 2.5 7B | Gratuito (Apache 2.0) |
| Redis | Gratuito (open source) |
| Python + Celery + FastAPI | Gratuito (open source) |
| SQLite | Gratuito |
| **Total mensal** | **R$ 0** |

### 11.3 — Custos futuros (opcionais)

| Item | Quando | Custo estimado |
|---|---|---|
| PostgreSQL hosting | Fase 4 | R$ 0 (self-hosted) |
| Domínio para dashboard | Fase 3 | ~R$ 40/ano |
| GPU dedicada (upgrade) | Se precisar de velocidade | R$ 800-1500 (RTX 3060 usada) |

---

## 12. Riscos e Mitigações

| Risco | Probabilidade | Impacto | Mitigação |
|---|---|---|---|
| Textos com "cara de IA" | Médio | Alto | Tom de voz rigoroso + exemplos bons/ruins + revisão por segunda IA |
| Modelo lento demais em CPU | Médio | Médio | Gemma 4 MoE é eficiente; batch noturno não requer velocidade |
| HD enche com artigos | Baixo | Baixo | 512 GB = ~500.000 artigos. Monitorar com alerta |
| Ollama crasha | Baixo | Médio | Restart automático via systemd |
| WordPress rejeita publicação | Médio | Baixo | Retry com backoff + notificação |
| Qualidade inconsistente entre ativos | Médio | Alto | Templates de prompt específicos + calibração por ativo |

---

## 13. Próximos Passos Imediatos

1. **Instalar Ubuntu Server 24.04 no MiniPC**
2. **Instalar Ollama + Gemma 4 26B A4B Q8 + Qwen 2.5 7B Q6**
3. **Teste manual:** gerar 1 artigo completo via prompt direto no Ollama
4. **Avaliar qualidade** do output bruto
5. **Ajustar prompts** até atingir qualidade satisfatória
6. **Iniciar desenvolvimento do MVP** (Fase 1)

---

*Documento criado por David ⚡ — 31/05/2026*  
*Projeto BigWriter — FBR Inc*  
*Controlado por: Sergio*
